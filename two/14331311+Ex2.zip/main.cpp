#include "Canny.h"

int main(void)
{
	Canny cny;
	cny.TestCanny();
	cny.TestHough();
	return 0;;
}
